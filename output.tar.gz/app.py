import os
from flask import Flask, render_template, request, redirect, url_for, flash
from flask_sqlalchemy import SQLAlchemy
from flask_cors import CORS
from datetime import datetime, timezone
from utils import get_address_info, get_detailed_transactions, create_transaction_flow_visualization
import csv

# Initialize SQLAlchemy without passing the app
db = SQLAlchemy()

def create_app():
    print("Starting to create the Flask app...")
    app = Flask(__name__)
    CORS(app)

    # Set up configurations
    app.secret_key = os.environ.get("FLASK_SECRET_KEY", "your-secret-key-here")
    app.config["SQLALCHEMY_DATABASE_URI"] = os.environ.get("DATABASE_URL", "sqlite:///local.db")
    app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

    # Initialize SQLAlchemy with the app
    db.init_app(app)

    # Import models and create tables within app context
    with app.app_context():
        from models import SuspiciousAddress, AddressCheck
        db.create_all()
        print("Database tables created.")

    # Define routes within this function
    register_routes(app)

    print("Flask app created successfully!")
    return app

def load_suspicious_addresses_from_csv(csv_filepath='hacker_addresses.csv', address=None):
    from models import SuspiciousAddress
    if not os.path.exists(csv_filepath):
        print(f"CSV file not found: {csv_filepath}")
        return

    with open(csv_filepath, newline='') as csvfile:
        reader = csv.DictReader(csvfile)
        for row in reader:
            if address and row['hacker_address'] != address:
                continue
            reason = row['report_type']
            existing = db.session.query(SuspiciousAddress).filter_by(address=address).first()
            if existing:
                existing.reason = reason
                existing.last_seen = datetime.now(timezone.utc)
            else:
                suspicious = SuspiciousAddress(
                    address=address,
                    cryptocurrency='BTC',
                    reason=reason,
                    first_seen=datetime.now(timezone.utc),
                    last_seen=datetime.now(timezone.utc),
                    risk_score=50
                )
                db.session.add(suspicious)
        db.session.commit()

def register_routes(app):
    @app.route('/')
    def home():
        return render_template('index.html')

    @app.route('/address/<string:address>', methods=['GET'])
    def address_info(address):
        from models import SuspiciousAddress
        load_suspicious_addresses_from_csv(address=address)

        suspicious = db.session.query(SuspiciousAddress).filter_by(address=address).first()
        address_data = get_address_info(address)

        if address_data is None:
            if suspicious:
                empty_wallet_message = (
                    f"This address shows no recent transaction data, "
                    f"but has been flagged previously for suspicious activity, "
                    f"specifically associated with {suspicious.reason}."
                )
            else:
                empty_wallet_message = "No recent transaction data is available for this address."

            return render_template(
                'result.html',
                address=address,
                address_info=None,
                transaction_viz=None,
                suspicious=suspicious,
                risk_score="No Data Available",
                empty_wallet_message=empty_wallet_message
            )

        if suspicious and suspicious.reason == 'Testing address':
            suspicious.reason = 'Unknown reason'
            db.session.commit()

        transactions = get_detailed_transactions(address)
        transaction_viz = None
        if transactions:
            transaction_viz = create_transaction_flow_visualization(transactions, address)

        return render_template(
            'result.html',
            address=address,
            address_info=address_data,
            transaction_viz=transaction_viz,
            suspicious=suspicious,
            risk_score=calculate_risk_score(address_data, suspicious)
        )

    @app.route('/check_address', methods=['POST'])
    def check_address():
        address = request.form.get('address')
        return redirect(url_for('address_info', address=address))

    @app.route('/report_address', methods=['GET', 'POST'])
    def report_address():
        from models import SuspiciousAddress
        if request.method == 'POST':
            address = request.form.get('address')
            existing = db.session.query(SuspiciousAddress).filter_by(address=address).first()
            if not existing:
                new_report = SuspiciousAddress(
                    address=address,
                    cryptocurrency='BTC',
                    reason='Reported by user',
                    first_seen=datetime.now(timezone.utc),
                    last_seen=datetime.now(timezone.utc),
                    risk_score=calculate_risk_score({}, None)
                )
                db.session.add(new_report)
                db.session.commit()
            flash('Address reported successfully', 'success')
            return redirect(url_for('home'))
        return render_template('report.html')

def calculate_risk_score(address_data, suspicious):
    if not address_data:
        return "No Data Available"

    # Extract data with defaults and add debug prints
    report_count = address_data.get("report_count", 0)
    transaction_volume = address_data.get("balance", 0)
    transaction_count = address_data.get("n_tx", 0)
    recent_activity = datetime.now(timezone.utc) if not address_data.get("recent_activity") else address_data["recent_activity"]
    reported_risk_level = suspicious.risk_score if suspicious else 0

    # Debug statements to confirm values
    print(f"Report Count: {report_count}")
    print(f"Transaction Volume: {transaction_volume}")
    print(f"Transaction Count: {transaction_count}")
    print(f"Recent Activity: {recent_activity}")
    print(f"Reported Risk Level: {reported_risk_level}")

    # Calculate risk score
    score = report_count * 10 + transaction_volume * 0.1 + transaction_count * 2 + reported_risk_level
    # Apply 50% reduction if last transaction is older than 180 days
    if (datetime.now(timezone.utc) - recent_activity).days > 180:
        score *= 0.5

    final_score = min(100, int(score))
    print(f"Final Risk Score: {final_score}")  # Final calculated score
    return final_score

if __name__ == "__main__":
    print("Running the Flask application...")
    app = create_app()
    app.run(host="0.0.0.0", port=5001, debug=True)
