import csv
import os
from datetime import datetime
from flask import render_template, request, redirect, url_for, flash
from models import SuspiciousAddress, AddressCheck
from utils import get_address_info, get_detailed_transactions, create_transaction_flow_visualization
from app import db

def load_suspicious_addresses_from_csv(csv_filepath='hacker_addresses.csv'):
    """Load suspicious addresses from a CSV file and update the database."""
    if not os.path.exists(csv_filepath):
        print(f"CSV file not found: {csv_filepath}")
        return

    with open(csv_filepath, newline='') as csvfile:
        reader = csv.DictReader(csvfile)
        for row in reader:
            address = row['hacker_address']
            reason = row['report_type']

            existing = SuspiciousAddress.query.filter_by(address=address).first()
            if existing:
                existing.reason = reason
                existing.last_seen = datetime.utcnow()
            else:
                suspicious = SuspiciousAddress(
                    address=address,
                    cryptocurrency='BTC',
                    reason=reason,
                    first_seen=datetime.utcnow(),
                    last_seen=datetime.utcnow(),
                    risk_score=50
                )
                db.session.add(suspicious)
        db.session.commit()
        print("Loaded suspicious addresses from CSV.")

def register_routes(app):
    @app.route('/')
    def home():
        return render_template('index.html')

    @app.route('/address/<string:address>', methods=['GET'])
    def address_info(address):
        """Display information about a given address."""
        load_suspicious_addresses_from_csv()  # Reload CSV data on each request

        # Fetch address information from the database
        suspicious = db.session.query(SuspiciousAddress).filter_by(address=address).first()

        if not suspicious:
            return render_template('not_found.html', address=address), 404

        if suspicious.reason == 'Testing address':
            suspicious.reason = 'Unknown reason'
            db.session.commit()

        # Fetch additional information using utility functions
        address_data = get_address_info(address)
        transactions = get_detailed_transactions(address)
        transaction_viz = None
        if transactions:
            transaction_viz = create_transaction_flow_visualization(transactions, address)

        return render_template(
            'result.html',
            address=address,
            address_info=address_data,
            transaction_viz=transaction_viz,
            suspicious=suspicious
        )

    @app.route('/check_address', methods=['POST'])
    def check_address():
        """Redirect to the address info page for a given address."""
        address = request.form.get('address')
        return redirect(url_for('address_info', address=address))

    @app.route('/report_address', methods=['GET', 'POST'])
    def report_address():
        """Report a suspicious address."""
        if request.method == 'POST':
            address = request.form.get('address')
            reason = request.form.get('reason', 'Reported by user').strip()
            risk_score = request.form.get('risk_score', type=int, default=50)

            existing = db.session.query(SuspiciousAddress).filter_by(address=address).first()
            if not existing:
                new_report = SuspiciousAddress(
                    address=address,
                    cryptocurrency='BTC',
                    reason=reason,
                    first_seen=datetime.utcnow(),
                    last_seen=datetime.utcnow(),
                    risk_score=risk_score
                )
                db.session.add(new_report)
                db.session.commit()
                flash('Address reported successfully', 'success')
            else:
                flash('This address has already been reported', 'warning')

            return redirect(url_for('home'))
        return render_template('report.html')
