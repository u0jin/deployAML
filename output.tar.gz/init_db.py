import csv
from app import create_app, db
from models import SuspiciousAddress
from datetime import datetime

app = create_app()

with app.app_context():
    # Drop all tables and recreate them to ensure a fresh start
    db.drop_all()
    db.create_all()

    # Load data from hacker_addresses.csv
    try:
        with open('hacker_addresses.csv', newline='') as csvfile:
            reader = csv.DictReader(csvfile)
            for row in reader:
                # Debug: print each row to confirm reading correctly
                print(f"Loading row: {row}")
                
                # Ensure row keys are correct
                if 'hacker_address' not in row or 'report_type' not in row:
                    print(f"Error: Missing required fields in row: {row}")
                    continue
                
                # Check if the address already exists in the database
                existing_address = SuspiciousAddress.query.filter_by(address=row['hacker_address']).first()
                if existing_address:
                    # Update existing address
                    existing_address.reason = row['report_type']
                    existing_address.last_seen = datetime.utcnow()
                    existing_address.risk_score = 50  # Update risk score if needed
                    print(f"Updated address {row['hacker_address']} in the database with reason: {row['report_type']}")
                else:
                    # Attempt to add new address
                    try:
                        new_address = SuspiciousAddress(
                            address=row['hacker_address'],
                            cryptocurrency='BTC',
                            reason=row['report_type'],
                            first_seen=datetime.utcnow(),
                            last_seen=datetime.utcnow(),
                            risk_score=50  # Default risk score for new entries
                        )
                        db.session.add(new_address)
                        print(f"Added address {row['hacker_address']} to the database with reason: {row['report_type']}")
                    except Exception as e:
                        print(f"Error adding address {row['hacker_address']}: {e}")
        
        # Commit the changes to the database
        db.session.commit()
        print("Database initialized with hacker addresses")

        # Debug: Print all entries in the SuspiciousAddress table to verify
        all_addresses = SuspiciousAddress.query.all()
        for address in all_addresses:
            print(f"Database entry: Address={address.address}, Reason={address.reason}, Risk Score={address.risk_score}")
    except FileNotFoundError:
        print("Error: hacker_addresses.csv file not found. Please make sure the file exists in the correct location.")
    except Exception as e:
        print(f"Error loading hacker addresses: {e}")
